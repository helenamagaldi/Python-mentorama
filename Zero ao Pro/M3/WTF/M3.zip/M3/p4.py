while True:
    lido = input('Entre um numero: ')
    num = int(lido)
    print(f'Numero: {num}')
        
